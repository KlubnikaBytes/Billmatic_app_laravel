<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ReceivedPayment;

class ReceivedPaymentController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'party_id' => 'required|exists:parties,id',
            'payment_date' => 'required|date',
            'payment_number' => 'required',
            'amount' => 'required|numeric',
            'payment_mode' => 'required',
        ]);

        $payment = ReceivedPayment::create([
            'user_id' => auth()->id(),
            'party_id' => $request->party_id,
            'payment_date' => $request->payment_date,
            'payment_number' => $request->payment_number,
            'amount' => $request->amount,
            'payment_mode' => $request->payment_mode,
        ]);

        return response()->json([
            'success' => true,
            'data' => $payment
        ]);
    }
}

